module com.lowewriter.addsubtract1 
{ 
requires javafx.controls; 
exports com.lowewriter.addsubtract1; 
} 
