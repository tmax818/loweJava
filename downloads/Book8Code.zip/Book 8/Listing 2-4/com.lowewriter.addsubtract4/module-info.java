module com.lowewriter.addsubtract4
{
requires javafx.controls;
exports com.lowewriter.addsubtract4;
}
