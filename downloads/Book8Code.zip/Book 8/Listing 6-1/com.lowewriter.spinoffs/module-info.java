module com.lowewriter.spinoffs 
{ 
requires javafx.controls; 
exports com.lowewriter.spinoffs; 
} 
