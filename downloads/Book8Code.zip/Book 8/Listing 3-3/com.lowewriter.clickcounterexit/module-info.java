module com.lowewriter.clickcounterexit 
{ 
requires javafx.controls; 
exports com.lowewriter.clickcounterexit; 
} 
