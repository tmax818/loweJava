module com.lowewriter.clickme
{
      requires javafx.controls;
      exports com.lowewriter.clickme;
}
