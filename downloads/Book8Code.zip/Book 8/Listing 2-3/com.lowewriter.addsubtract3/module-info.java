module com.lowewriter.addsubtract3
{
requires javafx.controls;
exports com.lowewriter.addsubtract3;
}
