module com.lowewriter.sceneswitcher 
{ 
requires javafx.controls; 
exports com.lowewriter.sceneswitcher; 
} 
