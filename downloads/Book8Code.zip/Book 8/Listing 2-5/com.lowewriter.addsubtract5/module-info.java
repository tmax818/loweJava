module com.lowewriter.addsubtract5
{
requires javafx.controls;
exports com.lowewriter.addsubtract5;
}
