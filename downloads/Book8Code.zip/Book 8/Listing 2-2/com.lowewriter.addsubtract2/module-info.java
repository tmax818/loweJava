module com.lowewriter.addsubtract2
{
requires javafx.controls;
exports com.lowewriter.addsubtract2;
}
