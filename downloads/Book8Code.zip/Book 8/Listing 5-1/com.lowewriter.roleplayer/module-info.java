module com.lowewriter.roleplayer 
{ 
requires javafx.controls; 
exports com.lowewriter.roleplayer; 
} 
