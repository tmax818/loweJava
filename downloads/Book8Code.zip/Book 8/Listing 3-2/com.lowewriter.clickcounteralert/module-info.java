module com.lowewriter.clickcounteralert 
{ 
requires javafx.controls; 
exports com.lowewriter.clickcounteralert; 
} 
