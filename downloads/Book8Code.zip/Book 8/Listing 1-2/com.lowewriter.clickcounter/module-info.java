module com.lowewriter.clickcounter
{
requires javafx.controls;
exports com.lowewriter.clickcounter;
}
